DROP TABLE IF EXISTS `#__com_socialpromoter_queues`;
